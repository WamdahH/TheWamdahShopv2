# Low Quality Goods

Control Measures: Do regular checks of the products Daily or Weekly to make sure and maintain the standards are fit for the customer. Allow customers to leave feedback to that these can also be reviewed and improved
Evaluation: Customers could put in an order for a product in which they expect to be in the best quality possible. 
Impact Level: High
Likelihood: Medium
Response: Make sure all products are up to standard. If the website is using a company to distribute these orders make sure that that company is making sure the product and delivery is up to standard
Responsibility: Wamdah Hassan